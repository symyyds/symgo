% 端边协同架构电信网络流量管理与控制示例
% 添加粒子群优化算法来优化流量控制机制

% 网络参数
numEdgeNodes = 3;  % 边缘节点数量
numCloudNodes = 2; % 中心节点数量
trafficIntensity = 10;  % 流量强度
simTime = 100;  % 仿真时间
dt = 1;  % 时间步长

% 初始化边缘节点流量和中心云流量
edgeTraffic = zeros(numEdgeNodes, simTime);
cloudTraffic = zeros(numCloudNodes, simTime);

% 随机生成边缘节点间的流量
for t = 1:simTime
    for i = 1:numEdgeNodes
        incomingTraffic = randi([0, trafficIntensity]);
        edgeTraffic(i, t) = incomingTraffic;
    end
end

% 模拟边缘设备的数据上传到中心云
for t = 1:simTime
    for j = 1:numCloudNodes
        cloudTraffic(j, t) = sum(edgeTraffic(:, t)) * 0.5; % 假设50%的边缘流量上传到云
    end
end

% 粒子群优化参数
numParticles = 10;  % 粒子数量
maxIter = 50;       % 最大迭代次数
w = 0.5;            % 惯性权重
c1 = 1;             % 个体学习因子
c2 = 2;             % 社会学习因子

% 初始化粒子位置和速度
positions = rand(numParticles, numEdgeNodes);  % 随机初始化粒子位置（控制策略）
velocities = zeros(numParticles, numEdgeNodes); % 初始化粒子速度
pBest = positions;  % 粒子历史最优位置
pBestVal = inf(numParticles, 1);  % 粒子历史最优值
gBest = zeros(1, numEdgeNodes);  % 全局最优位置
gBestVal = inf;  % 全局最优值

% 评估初始控制策略的效果
initialControl = positions(1, :);  % 取第一个粒子的初始位置作为初始控制策略
initialEffectiveness = evaluateControlEffectiveness(edgeTraffic, cloudTraffic, initialControl);

% PSO主循环
effectivenessHistory = zeros(maxIter, 1); % 保存每次迭代的全局最优值
for iter = 1:maxIter
    for p = 1:numParticles
        % 计算当前粒子的控制机制效果（简单损失函数示例）
        currentControl = positions(p, :);
        
        % 评估控制机制效果
        controlEffectiveness = evaluateControlEffectiveness(edgeTraffic, cloudTraffic, currentControl);

        % 更新粒子的历史最优
        if controlEffectiveness < pBestVal(p)
            pBestVal(p) = controlEffectiveness;
            pBest(p, :) = currentControl;
        end
        
        % 更新全局最优
        if controlEffectiveness < gBestVal
            gBestVal = controlEffectiveness;
            gBest = currentControl;
        end
    end
    
    % 保存每次迭代的全局最优值
    effectivenessHistory(iter) = gBestVal;
    
    % 更新粒子的速度和位置
    for p = 1:numParticles
        r1 = rand(1, numEdgeNodes);
        r2 = rand(1, numEdgeNodes);
        velocities(p, :) = w * velocities(p, :) + ...
                           c1 * r1 .* (pBest(p, :) - positions(p, :)) + ...
                           c2 * r2 .* (gBest - positions(p, :));
        positions(p, :) = positions(p, :) + velocities(p, :);
        
        % 确保粒子在边界内
        positions(p, :) = min(max(positions(p, :), 0), 1);  % 控制策略限制在 [0, 1] 之间
    end
end

% 评估最终控制策略的效果
finalEffectiveness = evaluateControlEffectiveness(edgeTraffic, cloudTraffic, gBest);

% 可视化结果

% 绘制最终控制策略
figure;
hold on;
for i = 1:numEdgeNodes
    bar(i, gBest(i), 'DisplayName', ['Edge Node ' num2str(i)]);
end
% title('优化后的控制策略');
% xlabel('边缘节点');
% ylabel('控制强度 (0-1)');
title('Optimized control strategy');
xlabel('edge node');
ylabel('Control intensity (0-1)');

legend show;
grid on;

% 绘制边缘节点和云节点的流量
figure;
hold on;
for i = 1:numEdgeNodes
    plot(1:simTime, edgeTraffic(i, :), 'DisplayName', ['Edge Node ' num2str(i)]);
end
for j = 1:numCloudNodes
    plot(1:simTime, cloudTraffic(j, :), '--', 'DisplayName', ['Cloud Node ' num2str(j)]);
end
% title('节点流量');
% xlabel('时间');
% ylabel('流量');

title('nodal flow');
xlabel('time');
ylabel('flux');
legend show;
grid on;

% 绘制PSO迭代的控制效果变化
figure;
plot(1:maxIter, effectivenessHistory, '-o', 'LineWidth', 2);
% title('PSO 迭代中的控制效果变化');
% xlabel('迭代次数');
% ylabel('控制效果值');

title('Changes in control effects in PSO iterations');
xlabel('Number of iterations');
ylabel('control effect value');
grid on;

% 绘制优化前后控制效果对比
figure;
bar([initialEffectiveness, finalEffectiveness]);
% set(gca, 'XTickLabel', {'优化前', '优化后'});
% title('优化前后控制效果对比');
% ylabel('控制效果值');

set(gca, 'XTickLabel', {'pre-optimization', 'post-optimization'});
title('Control effect comparison before and after optimization');
ylabel('control effect value');
grid on;


% 评估控制机制效果的函数
function effectiveness = evaluateControlEffectiveness(edgeTraffic, cloudTraffic, control)
    % 扩展控制策略以匹配流量的尺寸
    controlMatrix = repmat(control, size(edgeTraffic, 2), 1)';  % 重复控制策略

    % 评估边缘节点的流量控制
    edgeEffectiveness = sum(sum(edgeTraffic .* (1 - controlMatrix)));  
    cloudEffectiveness = sum(sum(cloudTraffic));  % 云端的流量总和

    effectiveness = edgeEffectiveness + cloudEffectiveness;  % 综合效果
end
